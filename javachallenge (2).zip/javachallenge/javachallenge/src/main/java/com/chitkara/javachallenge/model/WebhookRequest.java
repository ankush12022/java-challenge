package com.chitkara.javachallenge.model;

public class WebhookRequest {
    private String name;
    private String regNo;
    private String email;
}
